
public class EasterTester {

	public static void main(String[] args) {
		System.out.println(Easter.calcuate(2001));
		System.out.println(Easter.calcuate(2012));
		
		
 	}

}
