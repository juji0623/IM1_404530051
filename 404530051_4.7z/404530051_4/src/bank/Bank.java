package bank;

import java.util.ArrayList;

public class Bank {
	ArrayList<BankAccount> Account = new ArrayList<BankAccount>();
	
	public Bank(){
		
	}
	
	public BankAccount Find(int AccountNumber){
		BankAccount tempAccount = null;
		for(BankAccount account : Account){
			if(account.accountNumber == AccountNumber){
				tempAccount = account;
			}
		}
		return tempAccount;
	}
	
	void addAccount(int accountNumber, double initialBalance){
		BankAccount tempBankAccount = new BankAccount(accountNumber, initialBalance);
		Account.add(tempBankAccount);
	}
	
	void deposit(int accountNumber, double initialBalance){
		Find(accountNumber).deposit(initialBalance);
	}
	
	void withdraw(int accountNumber, double initialBalance){
		Find(accountNumber).withdraw(initialBalance);
	}
	
	double getBalance(int accountNumber){
		return Find(accountNumber).balance;
	}
	
	void suspendAccount(int accountNumber){
		Find(accountNumber).suspend();
	}
	
	void reOpenAccount(int accountNumber){
		Find(accountNumber).reOpen();
	}
	
	void closeAccount(int accountNumber){
		Find(accountNumber).close();
	}
	
	String getAccountStatus(int accountNumber){
		return Find(accountNumber).getStatus();
	}
	
	String summarizeAccountTransactions(int accountNumber){
		return Find(accountNumber).getTransactions();
	}
	
	String summarizeAllAccounts(){
		String Info = "Bank Account Summary\n \nAccount\t\tBalance\t\t#Transactions\t\tStatus\n";
		for(BankAccount account : Account){
			Info += "\n" + account.accountNumber +"\t\t" + account.balance + "\t\t" 
		+ Integer.toString(account.retrieveNumberOfTransactions()) + "\t\t" + account.AccountStatus ;
				}
		return Info + "\nEnd of Account Summary";
	}

}
