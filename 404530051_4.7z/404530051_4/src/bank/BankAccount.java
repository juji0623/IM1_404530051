package bank;

import java.util.ArrayList;

public class BankAccount {
	double balance = 0;
	int accountNumber;
	ArrayList<Double> TransactionList ;
	String AccountStatus ="open";

	public BankAccount(int AccountNumber,double amount)
	{				
		TransactionList = new ArrayList<Double>();						
		accountNumber = AccountNumber;
		balance = amount;
	} 	
	
	void deposit(double amount){
		
		    if (isOpen() && amount > 0){
			    balance += amount;
			    TransactionList.add(amount);
		    }

	}
	
	void withdraw(double amount){
		
				if(isOpen() && amount > 0 && amount <= balance){
					balance -= amount;
					TransactionList.add(-amount);					
				    }
	}
		
	boolean isOpen(){
		return AccountStatus.equals("open");
	}
	
	boolean isSuspended(){
		return AccountStatus.equals("suspended");
		}
	
	boolean isClose(){
		return AccountStatus.equals("closed");
	}
	void suspend(){
		
			AccountStatus="suspend";
		
	}
	
	void close(){
		

			AccountStatus="closed";
			
	}
	
	void reOpen(){
		
			AccountStatus="open";
						
	}
	
	public void addTranscation(double amount) {
		TransactionList.add(amount);
	}
	
	String getTransactions(){
		String info = "Account #" + accountNumber + " transactions:\n" ;
		int i=1;
		for(Double Balance : TransactionList){
			info = info+ i + ":" + Balance+"\n";
			i++;
		}
		return info + "\nEnd of transactions";
	}
	
	int retrieveNumberOfTransactions(){
		return TransactionList.size();
	}
	
	private void setStatus(String status){
		status = AccountStatus;
	}
	
	public String getStatus (){
		return AccountStatus;
		
	}
	
	
}
